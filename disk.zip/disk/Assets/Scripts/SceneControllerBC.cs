﻿using UnityEngine;  
using System.Collections;  
using Com.Mygame;  

namespace Com.Mygame {  
	public interface IUserInterface {  
		void emitDisk();  
	}  

	public interface IQueryStatus {  
		bool isCounting();  
		bool isShooting();  
		int getRound();  
		int getScore();  
		int getEmitTime();  
	}  

	public interface IJudgeEvent {  
		void nextRound();  
		void setScore(int Score);  
	}  

	public class SceneController : System.Object, IQueryStatus, IUserInterface, IJudgeEvent {  
		private static SceneController instance;  
		private SceneControllerBC baseCode;  
		private GameModel gameModel;  
		private Judge judge;  

		private int round;  
		private int score;  

		public static SceneController getInstance() {  
			if (instance == null) {  
				instance = new SceneController();  
			}  
			return instance;  
		}  

		public void setGameModel(GameModel obj) { 
			gameModel = obj;
		}  

		internal GameModel getGameModel() { 
			return gameModel;
		}  

		public void setJudge(Judge obj) { 
			judge = obj;
		}  

		internal Judge getJudge() { 
			return judge;
		}  

		public void setSceneControllerBC(SceneControllerBC obj) { 
			baseCode = obj;
		}  

		internal SceneControllerBC getSceneControllerBC() {
			return baseCode;
		}  

		public void emitDisk() { 
			gameModel.prepareToEmitDisk();
		}  
 
		public bool isCounting() { 
			return gameModel.isCounting();
		}  

		public bool isShooting() { 
			return gameModel.isShooting();
		}  

		public int getRound() { 
			return round; 
		}  

		public int getScore() { 
			return score;
		}  

		public int getEmitTime() { 
			return (int)gameModel.timeToEmit + 1;
		}  
 
		public void setScore(int score_) { 
			score = score_;
		}  
		public void nextRound() { 
			score = 0;
			baseCode.loadRoundData(++round);
		}  
	}  

	public class SceneControllerBC : MonoBehaviour {  
		private Color color;  
		private Vector3 emitPos;  
		private Vector3 emitDir;  
		private float speed;  

		void Awake() {  
			SceneController.getInstance().setSceneControllerBC(this);  
		}  

		public void loadRoundData(int round) {  
			if (round == 1) {
				color = Color.green;  
				emitPos = new Vector3(-2.5f, 0.2f, -5f);  
				emitDir = new Vector3(24.5f, 40.0f, 67f);  
				speed = 3;  
				SceneController.getInstance().getGameModel().setting(1, color, emitPos, emitDir.normalized, speed, 1);  
			}
			else if (round==2) {
				color = Color.red;  
				emitPos = new Vector3(2.5f, 0.2f, -5f);  
				emitDir = new Vector3(-24.5f, 35.0f, 67f);  
				speed = 4;  
				SceneController.getInstance().getGameModel().setting(1, color, emitPos, emitDir.normalized, speed, 2);  
			}
		}  
	}  
}  
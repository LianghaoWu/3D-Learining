﻿using UnityEngine;  
using UnityEngine.UI;  
using System.Collections;  
using Com.Mygame;  

public class UserInterface : MonoBehaviour {  
	public Text mainText;   
	public Text scoreText; 
	public Text roundText; 
	string ruleText = "按下空格键以发射飞碟，点击鼠标左键发射子弹，每打中一个飞碟可得到10分，每错过一个飞碟扣十分，累积到一定的分数可进入下一关。";

	private int round;  

	public GameObject bullet;           
	public ParticleSystem explosion;   
	public float fireRate = .25f;       
	public float speed = 500f;   

	private float nextFireTime;      

	private IUserInterface userInt;  
	private IQueryStatus queryInt;    

	void Start() {  
		bullet = GameObject.Instantiate(bullet) as GameObject;  
		explosion = GameObject.Instantiate(explosion) as ParticleSystem;  
		userInt = SceneController.getInstance() as IUserInterface;  
		queryInt = SceneController.getInstance() as IQueryStatus;  
	}  

	void Update () {  
		
		if (queryInt.isCounting()) {  
			mainText.text = ((int)queryInt.getEmitTime()).ToString();  
		}  
		else {  
			if (Input.GetKeyDown("space")) {  
				userInt.emitDisk();    
			}  
			if (queryInt.isShooting()) {  
				mainText.text = "";    
			}  
			if (queryInt.isShooting() && Input.GetMouseButtonDown(0) && Time.time > nextFireTime ) {  
				nextFireTime = Time.time + fireRate;  

				Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); 
				bullet.GetComponent<Rigidbody>().velocity = Vector3.zero;     
				bullet.transform.position= transform.position;           
				bullet.GetComponent<Rigidbody>().AddForce(ray.direction*speed, ForceMode.Impulse);  

				RaycastHit hit;  
				if (Physics.Raycast(ray, out hit) && hit.collider.gameObject.tag == "Disk") {  
					explosion.transform.position = hit.collider.gameObject.transform.position;  
					explosion.GetComponent<Renderer>().material.color = hit.collider.gameObject.GetComponent<Renderer>().material.color;  
					explosion.Play();  
					hit.collider.gameObject.SetActive(false);  
				}  
			}  
		}  
		roundText.text = "Round: " + queryInt.getRound().ToString();  
		scoreText.text = "Score: " + queryInt.getScore().ToString();
		if (round != queryInt.getRound()) {  
			Debug.Log (round);
			round = queryInt.getRound();  
			mainText.text = "Round " + round.ToString() + " !";  
			Debug.Log (round);
		}  
	} 

	void OnGUI() {
		if (GUI.RepeatButton (new Rect (10, 10, 100, 40), "Help")) {
			GUI.TextArea(new Rect(10, 60, 750, 100),ruleText);
		}
	}
}  
﻿using UnityEngine;  
using System.Collections;  
using Com.Mygame;  

public class Judge : MonoBehaviour {  
	public int oneDiskScore = 10;  
	public int oneDiskFail = 10;  
	public int disksToWin = 4;  

	private SceneController scene;  

	void Awake() {  
		scene = SceneController.getInstance();  
		scene.setJudge(this);  
	}  

	void Start() {  
		scene.nextRound();  
	}  

	public void scoreADisk() {  
		scene.setScore(scene.getScore() + oneDiskScore);  
		if (scene.getScore() == disksToWin*oneDiskScore) {  
			scene.nextRound();  
		}  
	}  
		
	public void failADisk() {  
		scene.setScore(scene.getScore() - oneDiskFail);  
	}  
}  